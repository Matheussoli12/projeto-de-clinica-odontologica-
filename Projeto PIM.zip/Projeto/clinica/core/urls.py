from django.urls import path
from . import views

urlpatterns = [
     path('', views.home, name='home'),
    path('paciente/', views.paciente_list, name='paciente_list'),
    path('atendimento/', views.atendimento_list, name='atendimento_list'),
    path('prontuario/', views.prontuario_list, name='prontuario_list'),
    path('atestado/', views.atestado_list, name='atestado_list'),
    path('medicamento/', views.medicamento_list, name='medicamento_list'),
    path('financeiro/', views.financeiro_list, name='financeiro_list'),
]
