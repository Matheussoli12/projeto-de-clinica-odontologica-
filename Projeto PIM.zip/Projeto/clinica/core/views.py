from django.shortcuts import render
from .models import Paciente, Atendimento, Prontuario, Atestado, Medicamento, Financeiro

def paciente_list(request):
    pacientes = Paciente.objects.all()
    return render(request, 'core/paciente_list.html', {'pacientes': pacientes})

def atendimento_list(request):
    atendimentos = Atendimento.objects.all()
    return render(request, 'core/atendimento_list.html', {'atendimentos': atendimentos})

def prontuario_list(request):
    prontuarios = Prontuario.objects.all()
    return render(request, 'core/prontuario_list.html', {'prontuarios': prontuarios})

def atestado_list(request):
    atestados = Atestado.objects.all()
    return render(request, 'core/atestado_list.html', {'atestados': atestados})

def medicamento_list(request):
    medicamentos = Medicamento.objects.all()
    return render(request, 'core/medicamento_list.html', {'medicamentos': medicamentos})

def financeiro_list(request):
    financeiros = Financeiro.objects.all()
    return render(request, 'core/financeiro_list.html', {'financeiros': financeiros})

def home(request):
    return render(request, 'core/home.html')

