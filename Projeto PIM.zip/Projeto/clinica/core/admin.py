from django.contrib import admin
from .models import Paciente, Atendimento, Prontuario, Atestado, Medicamento, Financeiro
from django.utils.html import format_html

@admin.register(Paciente)
class PacienteAdmin(admin.ModelAdmin):
    list_display = ('nome', 'data_nascimento', 'telefone', 'email', 'imagem_tag')
    search_fields = ('nome',)
    readonly_fields = ('imagem_tag',)

    def imagem_tag(self, obj):
        if obj.imagem:
            return format_html('<img src="{}" width="50" height="50" />'.format(obj.imagem.url))
        return ""
    imagem_tag.short_description = 'Imagem'

@admin.register(Atendimento)
class AtendimentoAdmin(admin.ModelAdmin):
    list_display = ('paciente', 'data', 'descricao')
    search_fields = ('paciente__nome',)

@admin.register(Prontuario)
class ProntuarioAdmin(admin.ModelAdmin):
    list_display = ('paciente', 'historico')

@admin.register(Atestado)
class AtestadoAdmin(admin.ModelAdmin):
    list_display = ('paciente', 'descricao', 'data_emissao')

@admin.register(Medicamento)
class MedicamentoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'descricao')

@admin.register(Financeiro)
class FinanceiroAdmin(admin.ModelAdmin):
    list_display = ('paciente', 'valor', 'data', 'descricao')
    search_fields = ('paciente__nome',)

