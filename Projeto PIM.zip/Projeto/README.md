Odonto BSB - Sistema de Gerenciamento de Clínica Odontológica
Descrição do Projeto
Este projeto é um sistema de gerenciamento de uma clínica odontológica, chamado Odonto BSB. Ele permite o cadastro de pacientes, prontuários, atendimentos, receitas, e muito mais, ajudando a clínica a organizar seus dados de forma eficiente.

Pré-requisitos
Python 3.10+
Django
Ambiente Virtual (recomendado)

Clonar o Repositório
Se você está usando um sistema de controle de versão (como Git), comece clonando o repositório.

git clone <URL-do-repositório>
cd <nome-da-pasta-do-projeto>

Criar e Ativar o Ambiente Virtual
Para manter as dependências do projeto isoladas, crie e ative um ambiente virtual:

python -m venv venv
venv\Scripts\activate

Instalar Dependências
Com o ambiente virtual ativo, instale todas as dependências necessárias listadas no arquivo requirements.txt:

pip install -r requirements.txt

Configurar o Banco de Dados
Crie as tabelas no banco de dados aplicando as migrações:

python manage.py migrate

Coletar Arquivos Estáticos
Para garantir que todos os arquivos estáticos (CSS, JavaScript, etc.) estejam organizados, execute:

python manage.py collectstatic
Digite "yes" quando solicitado.

 Executar o Servidor
Inicie o servidor de desenvolvimento do Django:

python manage.py runserver
O projeto estará disponível em http://127.0.0.1:8000/

Página inicial: http://127.0.0.1:8000/
Pacientes: http://127.0.0.1:8000/pacientes/
Atendimentos: http://127.0.0.1:8000/atendimentos/
Prontuários: http://127.0.0.1:8000/prontuarios/
Administração: http://127.0.0.1:8000/admin/

Funcionalidades Principais
Cadastro e gerenciamento de pacientes.
Registro de atendimentos e prontuários.
Emissão de receitas e atestados.
Gerenciamento financeiro.